import xlrd
import random
import webbrowser
import time

file_address = r'./复习问题收集.xls'	# 文件位置
url = r'https://www.bilibili.com/video/av48922404?from=search&seid=1303575603890789311'
sheet1 = []
row = 0
row_ls = []

def print_gap():
	gap = 10	# 空行数目
	for i in range(gap):
		print()

def read_excel():
	global sheet1, row, row_ls
	excel_contain = xlrd.open_workbook(filename = file_address)
#	print('Excel内所有表格名字：', excel_contain.sheet_names())
	sheet1 = excel_contain.sheet_by_name('问答')
	row = sheet1.nrows - 1
	row_ls = [i for i in range(1, row)]
#	print('表格名字：', sheet1.name, '，行数：', sheet1.nrows, '，列数：', sheet1.ncols)
	
def round_random():
	temp = row_ls[random.randint(0, len(row_ls) - 1)]
	row_ls.remove(temp)
	return temp

def random_question():
	index_of_question = round_random()
	index_str = (str)(sheet1.cell(rowx = index_of_question, colx = 0).value)
	index = index_str.replace('.0', '')
	question = sheet1.cell(rowx = index_of_question, colx = 1).value
	answer = sheet1.cell(rowx = index_of_question, colx = 2).value
	print(index, question)
	return answer


read_excel()
print('a：显示这一题答案，并输出下一题')
while True:
	print()
	print('还剩', len(row_ls), '题')
	answer = random_question()
	method = input()
	if method == 'a':
		print(answer)
	else:
		break
	if len(row_ls) == 0:
		break
	print('########################################################################################################################')

if len(row_ls) == 0:
	print('!!!恭喜你完成一轮，放松一下叭!!!')
	time.sleep(3)
	webbrowser.open(url)